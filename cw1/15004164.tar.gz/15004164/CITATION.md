To cite Alchemist in your laboratory publications, please use:

Daithi and M. Minnow. Alchemist. UCL, 2018.